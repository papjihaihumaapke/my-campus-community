import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Post } from "@shared/schema";
import { CreatePost } from "@/components/create-post";
import { PostCard } from "@/components/post-card";
import { MobileNav } from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const categories = ["All", "Academic", "Campus Life", "Resources", "Events", "Questions"];
const campuses = ["All", "Main Campus", "Downtown Campus", "Health Sciences Campus", "Engineering Campus"];

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedCampus, setSelectedCampus] = useState(user?.campus || "All");

  const { data: posts, isLoading } = useQuery<Post[]>({
    queryKey: [
      "/api/posts",
      selectedCategory !== "All" ? `?category=${selectedCategory}` : "",
      selectedCampus !== "All" ? `&campus=${selectedCampus}` : "",
    ],
  });

  if (!user) return null; // Protected route will handle redirect

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-xl font-bold">Campus Connect</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {user.campus}
            </span>
            <Button
              variant="ghost"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-3xl">
        <div className="mb-6">
          <CreatePost />
        </div>

        <div className="mb-6 space-y-4">
          <div className="flex gap-2 overflow-x-auto pb-2">
            <Select
              value={selectedCampus}
              onValueChange={setSelectedCampus}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select campus" />
              </SelectTrigger>
              <SelectContent>
                {campuses.map((campus) => (
                  <SelectItem key={campus} value={campus}>
                    {campus}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 overflow-x-auto">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4">
            {posts?.map((post) => (
              <PostCard key={post.id} post={post} currentUser={user} />
            ))}
            {!posts?.length && (
              <div className="text-center py-8 text-muted-foreground">
                No posts found. Be the first to share!
              </div>
            )}
          </div>
        )}
      </main>

      <MobileNav />
    </div>
  );
}