import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Post, User, Comment, Vote, insertCommentSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import {
  ArrowUpCircle,
  ArrowDownCircle,
  MessageCircle,
  Calendar,
} from "lucide-react";
import { format } from "date-fns";

export function PostCard({
  post,
  currentUser,
}: {
  post: Post;
  currentUser: User;
}) {
  const [showComments, setShowComments] = useState(false);

  const { data: comments } = useQuery<Comment[]>({
    queryKey: ["/api/posts", post.id, "comments"],
    enabled: showComments,
  });

  const { data: votes } = useQuery<Vote[]>({
    queryKey: ["/api/posts", post.id, "votes"],
  });

  const voteMutation = useMutation({
    mutationFn: async (value: number) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/votes`, {
        value,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/posts", post.id, "votes"],
      });
    },
  });

  const commentForm = useForm({
    resolver: zodResolver(insertCommentSchema),
    defaultValues: { content: "", postId: post.id },
  });

  const commentMutation = useMutation({
    mutationFn: async (data: { content: string }) => {
      const res = await apiRequest(
        "POST",
        `/api/posts/${post.id}/comments`,
        data,
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/posts", post.id, "comments"],
      });
      commentForm.reset();
    },
  });

  const voteCount = votes?.reduce((acc, vote) => acc + vote.value, 0) ?? 0;
  const userVote = votes?.find((vote) => vote.userId === currentUser.id)?.value;

  return (
    <Card>
      <CardHeader className="flex flex-row items-start gap-4">
        <div className="flex flex-col items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => voteMutation.mutate(1)}
            className={userVote === 1 ? "text-primary" : ""}
          >
            <ArrowUpCircle className="h-5 w-5" />
          </Button>
          <span className="text-sm font-medium">{voteCount}</span>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => voteMutation.mutate(-1)}
            className={userVote === -1 ? "text-primary" : ""}
          >
            <ArrowDownCircle className="h-5 w-5" />
          </Button>
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="font-medium">{post.category}</span>
            <span>•</span>
            <Calendar className="h-4 w-4" />
            <span>{format(new Date(post.createdAt), "MMM d, yyyy")}</span>
          </div>
          <h3 className="text-lg font-semibold mt-1">{post.title}</h3>
          <p className="mt-2">{post.content}</p>
        </div>
      </CardHeader>

      <CardFooter className="flex-col gap-4">
        <Button
          variant="ghost"
          className="w-full"
          onClick={() => setShowComments(!showComments)}
        >
          <MessageCircle className="h-4 w-4 mr-2" />
          {comments?.length ?? 0} Comments
        </Button>

        {showComments && (
          <div className="w-full space-y-4">
            <Form {...commentForm}>
              <form
                onSubmit={commentForm.handleSubmit((data) =>
                  commentMutation.mutate(data)
                )}
                className="space-y-2"
              >
                <FormField
                  control={commentForm.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea
                          placeholder="Add a comment..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={commentMutation.isPending}
                >
                  Post Comment
                </Button>
              </form>
            </Form>

            <div className="space-y-4">
              {comments?.map((comment) => (
                <Card key={comment.id}>
                  <CardContent className="pt-4">
                    <p>{comment.content}</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      {format(new Date(comment.createdAt), "MMM d, yyyy")}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
