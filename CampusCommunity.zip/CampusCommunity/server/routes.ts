import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from 'fs';
import express from 'express';
import { insertPostSchema, insertCommentSchema, insertVoteSchema, insertUserSchema, insertFeedbackSchema } from "@shared/schema";

const upload = multer({
  storage: multer.diskStorage({
    destination: './uploads',
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Create uploads directory if it doesn't exist
  if (!fs.existsSync('./uploads')) {
    fs.mkdirSync('./uploads');
  }

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  // User profile update
  app.patch("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertUserSchema.partial().safeParse(req.body);
    if (!validation.success) return res.status(400).json(validation.error);

    const user = await storage.updateUser(req.user.id, validation.data);
    res.json(user);
  });

  // Profile picture upload
  app.post("/api/user/profile-picture", upload.single('profilePicture'), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });

    const profilePicture = `/uploads/${req.file.filename}`;
    const user = await storage.updateUser(req.user.id, { profilePicture });
    res.json(user);
  });

  // Posts
  app.get("/api/posts", async (req, res) => {
    const { category, campus } = req.query;
    let posts;

    if (campus && category && category !== "All") {
      posts = await storage.getPostsByCampusAndCategory(campus as string, category as string);
    } else if (campus) {
      posts = await storage.getPostsByCampus(campus as string);
    } else if (category && category !== "All") {
      posts = await storage.getPostsByCategory(category as string);
    } else {
      posts = await storage.getPosts();
    }

    res.json(posts);
  });

  // Comments
  app.get("/api/posts/:postId/comments", async (req, res) => {
    const comments = await storage.getCommentsByPost(Number(req.params.postId));
    res.json(comments);
  });

  app.post("/api/posts/:postId/comments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertCommentSchema.safeParse({
      ...req.body,
      postId: Number(req.params.postId),
    });
    if (!validation.success) return res.status(400).json(validation.error);

    const comment = await storage.createComment({
      ...validation.data,
      userId: req.user.id,
    });
    res.status(201).json(comment);
  });

  // Votes
  app.post("/api/posts/:postId/votes", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertVoteSchema.safeParse({
      ...req.body,
      postId: Number(req.params.postId),
    });
    if (!validation.success) return res.status(400).json(validation.error);

    const vote = await storage.createOrUpdateVote({
      ...validation.data,
      userId: req.user.id,
    });
    res.status(201).json(vote);
  });

  app.get("/api/posts/:postId/votes", async (req, res) => {
    const votes = await storage.getVotesByPost(Number(req.params.postId));
    res.json(votes);
  });

  app.post("/api/posts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertPostSchema.safeParse(req.body);
    if (!validation.success) return res.status(400).json(validation.error);

    const post = await storage.createPost({
      ...validation.data,
      userId: req.user.id,
    });
    res.status(201).json(post);
  });

  // User search
  app.get("/api/users/search", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { query, campus } = req.query;
    let users = await storage.searchUsers(query as string, campus as string);

    // Remove sensitive information
    users = users.map(({ password, ...user }) => user);
    res.json(users);
  });

  // Feedback routes
  app.post("/api/feedback", async (req, res) => {
    const validation = insertFeedbackSchema.safeParse(req.body);
    if (!validation.success) return res.status(400).json(validation.error);

    const feedback = await storage.createFeedback(validation.data);
    res.status(201).json(feedback);
  });

  app.get("/api/feedback", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { campus } = req.query;
    const feedback = campus
      ? await storage.getFeedbackByCampus(campus as string)
      : await storage.getAllFeedback();

    res.json(feedback);
  });

  app.patch("/api/feedback/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { status } = req.body;
    if (!status || !["pending", "in-progress", "completed"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const feedback = await storage.updateFeedbackStatus(
      Number(req.params.id),
      status
    );
    res.json(feedback);
  });

  const httpServer = createServer(app);
  return httpServer;
}