import { User, Post, Comment, Vote, Feedback, InsertUser, InsertPost, InsertComment, InsertVote, InsertFeedback } from "@shared/schema";
import { db } from "./db";
import { eq, and, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { users, posts, comments, votes, feedback } from "@shared/schema";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;

  // Post operations
  createPost(post: InsertPost & { userId: number }): Promise<Post>;
  getPosts(): Promise<Post[]>;
  getPostsByCategory(category: string): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  getPostsByCampus(campus: string): Promise<Post[]>;
  getPostsByCampusAndCategory(campus: string, category: string): Promise<Post[]>;

  // Comment operations
  createComment(comment: InsertComment & { userId: number }): Promise<Comment>;
  getCommentsByPost(postId: number): Promise<Comment[]>;

  // Vote operations
  createOrUpdateVote(vote: InsertVote & { userId: number }): Promise<Vote>;
  getVotesByPost(postId: number): Promise<Vote[]>;
  getVoteByUserAndPost(userId: number, postId: number): Promise<Vote | undefined>;

  // Search functionality
  searchUsers(query: string, campus?: string): Promise<User[]>;

  // New feedback interfaces
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getFeedbackByCampus(campus: string): Promise<Feedback[]>;
  getAllFeedback(): Promise<Feedback[]>;
  updateFeedbackStatus(id: number, status: string): Promise<Feedback>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async createPost(insertPost: InsertPost & { userId: number }): Promise<Post> {
    const [post] = await db.insert(posts).values(insertPost).returning();
    return post;
  }

  async getPosts(): Promise<Post[]> {
    return await db.select().from(posts).orderBy(posts.createdAt);
  }

  async getPostsByCategory(category: string): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.category, category))
      .orderBy(posts.createdAt);
  }

  async getPost(id: number): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }

  async getPostsByCampus(campus: string): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.campus, campus))
      .orderBy(posts.createdAt);
  }

  async getPostsByCampusAndCategory(campus: string, category: string): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(and(eq(posts.campus, campus), eq(posts.category, category)))
      .orderBy(posts.createdAt);
  }

  async createComment(
    insertComment: InsertComment & { userId: number },
  ): Promise<Comment> {
    const [comment] = await db.insert(comments).values(insertComment).returning();
    return comment;
  }

  async getCommentsByPost(postId: number): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(comments.createdAt);
  }

  async createOrUpdateVote(
    insertVote: InsertVote & { userId: number },
  ): Promise<Vote> {
    const existingVote = await this.getVoteByUserAndPost(
      insertVote.userId,
      insertVote.postId,
    );

    if (existingVote) {
      const [updatedVote] = await db
        .update(votes)
        .set({ value: insertVote.value })
        .where(eq(votes.id, existingVote.id))
        .returning();
      return updatedVote;
    }

    const [vote] = await db.insert(votes).values(insertVote).returning();
    return vote;
  }

  async getVotesByPost(postId: number): Promise<Vote[]> {
    return await db.select().from(votes).where(eq(votes.postId, postId));
  }

  async getVoteByUserAndPost(
    userId: number,
    postId: number,
  ): Promise<Vote | undefined> {
    const [vote] = await db
      .select()
      .from(votes)
      .where(
        and(eq(votes.userId, userId), eq(votes.postId, postId)),
      );
    return vote;
  }

  async searchUsers(query: string, campus?: string): Promise<User[]> {
    let queryBuilder = db.select().from(users);

    if (query) {
      queryBuilder = queryBuilder.where(sql`username ILIKE ${`%${query}%`}`);
    }

    if (campus && campus !== "All") {
      queryBuilder = queryBuilder.where(eq(users.campus, campus));
    }

    return await queryBuilder;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const [result] = await db.insert(feedback).values(insertFeedback).returning();
    return result;
  }

  async getFeedbackByCampus(campus: string): Promise<Feedback[]> {
    return await db
      .select()
      .from(feedback)
      .where(eq(feedback.campus, campus))
      .orderBy(feedback.createdAt);
  }

  async getAllFeedback(): Promise<Feedback[]> {
    return await db.select().from(feedback).orderBy(feedback.createdAt);
  }

  async updateFeedbackStatus(id: number, status: string): Promise<Feedback> {
    const [result] = await db
      .update(feedback)
      .set({ status })
      .where(eq(feedback.id, id))
      .returning();
    return result;
  }
}

export const storage = new DatabaseStorage();